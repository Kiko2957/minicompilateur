/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package compil;

/**
 *
 * @author HP
 */


import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Lexer {

    private final String source;
    private final int length;
    private int pos = 0;
    private int line = 1;
    private int column = 1;

    private final List<String> errors = new ArrayList<>();

    private static final Map<String, TokenType> keywords = new HashMap<>();
    static {
        keywords.put("if", TokenType.IF);
        keywords.put("else", TokenType.ELSE);
        keywords.put("let", TokenType.LET);
        keywords.put("var", TokenType.VAR);
        keywords.put("true", TokenType.TRUE);
        keywords.put("false", TokenType.FALSE);

        // 👉 Mets ton nom/prénom ici comme mots-clés
        keywords.put("Celine", TokenType.NOM);
        keywords.put("Milaz", TokenType.PRENOM);
    }

    public Lexer(String source) {
        this.source = source;
        this.length = source.length();
    }

    public List<String> getErrors() {
        return errors;
    }

    private char currentChar() {
        if (pos >= length) return '\0';
        return source.charAt(pos);
    }

    private char peek() {
        if (pos + 1 >= length) return '\0';
        return source.charAt(pos + 1);
    }

    private void advance() {
        if (pos < length) {
            if (currentChar() == '\n') {
                line++;
                column = 1;
            } else {
                column++;
            }
            pos++;
        }
    }

    private boolean match(char expected) {
        if (currentChar() == expected) {
            advance();
            return true;
        }
        return false;
    }

    private void skipWhitespaceAndComments() {
        boolean again;
        do {
            again = false;
            while (Character.isWhitespace(currentChar())) {
                advance();
                again = true;
            }
            // Commentaire ligne : //
            if (currentChar() == '/' && peek() == '/') {
                while (currentChar() != '\n' && currentChar() != '\0') {
                    advance();
                }
                again = true;
            }
        } while (again);
    }

    public Token nextToken() {
        skipWhitespaceAndComments();

        int startLine = line;
        int startColumn = column;
        char c = currentChar();

        if (c == '\0') {
            return new Token(TokenType.EOF, "", startLine, startColumn);
        }

        // Identifiant ou mot-clé
        if (Character.isLetter(c) || c == '_' || c == '$') {
            StringBuilder sb = new StringBuilder();
            while (Character.isLetterOrDigit(currentChar()) ||
                   currentChar() == '_' || currentChar() == '$') {
                sb.append(currentChar());
                advance();
            }
            String lex = sb.toString();
            TokenType type = keywords.getOrDefault(lex, TokenType.IDENTIFIER);
            return new Token(type, lex, startLine, startColumn);
        }

        // Nombre
        if (Character.isDigit(c)) {
            StringBuilder sb = new StringBuilder();
            while (Character.isDigit(currentChar())) {
                sb.append(currentChar());
                advance();
            }
            return new Token(TokenType.NUMBER, sb.toString(), startLine, startColumn);
        }

        // Opérateurs et ponctuation
        switch (c) {
            case '+':
                advance();
                if (currentChar() == '+') {
                    advance();
                    return new Token(TokenType.INCREMENT, "++", startLine, startColumn);
                }
                return new Token(TokenType.PLUS, "+", startLine, startColumn);
            case '-':
                advance();
                if (currentChar() == '-') {
                    advance();
                    return new Token(TokenType.DECREMENT, "--", startLine, startColumn);
                }
                return new Token(TokenType.MINUS, "-", startLine, startColumn);
            case '*':
                advance();
                return new Token(TokenType.STAR, "*", startLine, startColumn);
            case '/':
                advance();
                return new Token(TokenType.SLASH, "/", startLine, startColumn);
            case '=':
                advance();
                if (currentChar() == '=') {
                    advance();
                    return new Token(TokenType.EQ, "==", startLine, startColumn);
                }
                return new Token(TokenType.ASSIGN, "=", startLine, startColumn);
            case '!':
                advance();
                if (currentChar() == '=') {
                    advance();
                    return new Token(TokenType.NEQ, "!=", startLine, startColumn);
                }
                break;
            case '<':
                advance();
                if (currentChar() == '=') {
                    advance();
                    return new Token(TokenType.LE, "<=", startLine, startColumn);
                }
                return new Token(TokenType.LT, "<", startLine, startColumn);
            case '>':
                advance();
                if (currentChar() == '=') {
                    advance();
                    return new Token(TokenType.GE, ">=", startLine, startColumn);
                }
                return new Token(TokenType.GT, ">", startLine, startColumn);
            case '(':
                advance();
                return new Token(TokenType.LPAREN, "(", startLine, startColumn);
            case ')':
                advance();
                return new Token(TokenType.RPAREN, ")", startLine, startColumn);
            case '{':
                advance();
                return new Token(TokenType.LBRACE, "{", startLine, startColumn);
            case '}':
                advance();
                return new Token(TokenType.RBRACE, "}", startLine, startColumn);
            case ';':
                advance();
                return new Token(TokenType.SEMICOLON, ";", startLine, startColumn);
        }

        // Si on arrive ici : caractère inconnu
        String msg = "Erreur lexicale: caractère inattendu '" + c +
                     "' à la ligne " + startLine + ", colonne " + startColumn;
        errors.add(msg);
        advance();
        return new Token(TokenType.UNKNOWN, String.valueOf(c), startLine, startColumn);
    }

    public List<Token> tokenize() {
        List<Token> tokens = new ArrayList<>();
        Token t;
        do {
            t = nextToken();
            tokens.add(t);
        } while (t.type != TokenType.EOF);
        return tokens;
    }
}
