package compil;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author HP
 */


public enum TokenType {
    // Mots-clés
    IF, ELSE, LET, VAR, TRUE, FALSE,

    // Nom / prénom (mots-clés perso)
    NOM, PRENOM,

    // Identifiants et nombres
    IDENTIFIER, NUMBER,

    // Opérateurs
    PLUS, MINUS, STAR, SLASH,
    ASSIGN,           // =
    EQ, NEQ, LT, GT, LE, GE,   // ==, !=, <, >, <=, >=
    INCREMENT, DECREMENT,      // ++, --

    // Symboles
    LPAREN, RPAREN,            // ( )
    LBRACE, RBRACE,            // { }
    SEMICOLON,                 // ;

    // Fin de fichier
    EOF,

    // Inconnu (erreur lexicale)
    UNKNOWN
}


