/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package compil;


import java.util.ArrayList;
import java.util.List;

public class Parser {

    private final List<Token> tokens;
    private int pos = 0;
    private final List<String> errors = new ArrayList<>();

    public Parser(List<Token> tokens) {
        this.tokens = tokens;
    }

    public List<String> getErrors() {
        return errors;
    }

    // ---------- Outils de base ----------

    private Token current() {
        if (pos >= tokens.size()) {
            return tokens.get(tokens.size() - 1);
        }
        return tokens.get(pos);
    }

    private boolean match(TokenType... types) {
        for (TokenType t : types) {
            if (current().type == t) {
                pos++;
                return true;
            }
        }
        return false;
    }

    private Token expect(TokenType expectedType, String message) {
        if (current().type == expectedType) {
            Token t = current();
            pos++;
            return t;
        } else {
            Token t = current();
            errors.add("Erreur syntaxique: " + message +
                    " (attendu: " + expectedType +
                    ", trouvé: " + t.type +
                    ") à la ligne " + t.line +
                    ", colonne " + t.column);
            // récupération simple : on avance quand même
            pos++;
            return t;
        }
    }

    // ---------- Point d'entrée ----------

    public void parseProgram() {
        parseStatementList();
        expect(TokenType.EOF, "Fin de fichier attendue");
    }

    // STATEMENT_LIST → STATEMENT STATEMENT_LIST | ε
    private void parseStatementList() {
        while (current().type != TokenType.EOF &&
               current().type != TokenType.RBRACE) {
            parseStatement();
        }
    }

    // STATEMENT → VAR_DECL | ASSIGN | INC_DEC | IF_STMT | BLOCK
    private void parseStatement() {
        switch (current().type) {
            case LET:
            case VAR:
                parseVarDecl();
                break;

            case IF:
                parseIf();
                break;

            case IDENTIFIER:
                parseAssignOrIncDec();
                break;

            case LBRACE:
                parseBlock();
                break;

            default:
                errors.add("Instruction inattendue: " + current().type +
                           " à la ligne " + current().line);
                pos++; // pour éviter de boucler
        }
    }

    // BLOCK → '{' STATEMENT_LIST '}'
    private void parseBlock() {
        expect(TokenType.LBRACE, "Symbole '{' attendu pour ouvrir un bloc");
        parseStatementList();
        expect(TokenType.RBRACE, "Symbole '}' attendu pour fermer un bloc");
    }

    // VAR_DECL → ('let' | 'var') IDENTIFIER VAR_INIT_OPT ';'
    private void parseVarDecl() {
        // consomme LET ou VAR
        pos++; // on sait que c'est LET ou VAR

        expect(TokenType.IDENTIFIER, "Identifiant attendu après let/var");

        if (match(TokenType.ASSIGN)) {
            parseExpr();
        }

        expect(TokenType.SEMICOLON, "Point-virgule ';' attendu après la déclaration");
    }

    // ASSIGN → IDENTIFIER '=' EXPR ';'
    // INC_DEC → IDENTIFIER ('++' | '--') ';'
    private void parseAssignOrIncDec() {
        Token id = expect(TokenType.IDENTIFIER, "Identifiant attendu");

        if (match(TokenType.ASSIGN)) {
            parseExpr();
            expect(TokenType.SEMICOLON, "Point-virgule ';' attendu après l'affectation");
        } else if (match(TokenType.INCREMENT, TokenType.DECREMENT)) {
            expect(TokenType.SEMICOLON, "Point-virgule ';' attendu après ++ ou --");
        } else {
            errors.add("Instruction incorrecte après identifiant '" + id.lexeme +
                       "' à la ligne " + id.line);
            // récupération : on saute jusqu'au prochain ';' ou '}' ou EOF
            while (current().type != TokenType.SEMICOLON &&
                   current().type != TokenType.RBRACE &&
                   current().type != TokenType.EOF) {
                pos++;
            }
            if (current().type == TokenType.SEMICOLON) pos++;
        }
    }

    // IF_STMT → 'if' '(' EXPR ')' BLOCK ('else' BLOCK)?
    private void parseIf() {
        expect(TokenType.IF, "Mot-clé 'if' attendu");
        expect(TokenType.LPAREN, "Parenthèse '(' attendue après 'if'");
        parseExpr();
        expect(TokenType.RPAREN, "Parenthèse ')' attendue après la condition");
        parseBlock();

        if (match(TokenType.ELSE)) {
            parseBlock();
        }
    }

    // ---------- Expressions ----------

    // EXPR → TERM ( (== | != | < | > | <= | >=) TERM )*
    private void parseExpr() {
        parseTerm();
        while (match(TokenType.EQ, TokenType.NEQ,
                     TokenType.LT, TokenType.GT,
                     TokenType.LE, TokenType.GE)) {
            parseTerm();
        }
    }

    // TERM → FACTOR ( ('+' | '-') FACTOR )*
    private void parseTerm() {
        parseFactor();
        while (match(TokenType.PLUS, TokenType.MINUS)) {
            parseFactor();
        }
    }

    // FACTOR → PRIMARY ( ('*' | '/') PRIMARY )*
    private void parseFactor() {
        parsePrimary();
        while (match(TokenType.STAR, TokenType.SLASH)) {
            parsePrimary();
        }
    }

    // PRIMARY → IDENTIFIER | NUMBER | TRUE | FALSE | NOM | PRENOM | '(' EXPR ')'
    private void parsePrimary() {
        switch (current().type) {
            case IDENTIFIER:
            case NUMBER:
            case TRUE:
            case FALSE:
            case NOM:
            case PRENOM:
                pos++;
                break;

            case LPAREN:
                pos++;
                parseExpr();
                expect(TokenType.RPAREN, "Parenthèse ')' attendue");
                break;

            default:
                errors.add("Expression attendue à la ligne " + current().line +
                           ", trouvé: " + current().type);
                pos++;
        }
    }
}
