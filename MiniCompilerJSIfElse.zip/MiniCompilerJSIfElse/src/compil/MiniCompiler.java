/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package compil;


import java.util.List;

public class MiniCompiler {
    public static void main(String[] args) {

        String code = """
           5amine
        """;

        // 1) Analyse lexicale
        Lexer lexer = new Lexer(code);
        List<Token> tokens = lexer.tokenize();

        System.out.println("=== TOKENS ===");
        for (Token t : tokens) {
            System.out.println(t);
        }

        if (!lexer.getErrors().isEmpty()) {
            System.out.println("\n=== Erreurs lexicales ===");
            lexer.getErrors().forEach(System.out::println);
        }

         //2) Analyse syntaxique
      Parser parser = new Parser(tokens);
       parser.parseProgram();

       if (lexer.getErrors().isEmpty() && parser.getErrors().isEmpty()) {
           System.out.println("\n✅ Programme syntaxiquement correct.");
        } else {
           System.out.println("\n=== Erreurs syntaxiques ===");
            parser.getErrors().forEach(System.out::println);
       }
    }
}
