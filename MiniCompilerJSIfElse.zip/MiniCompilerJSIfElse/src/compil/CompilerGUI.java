/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package compil;


import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.util.List;

public class CompilerGUI extends JFrame {

    private JTextArea codeArea;
    private JTextArea tokensArea;
    private JTextArea errorsArea;
    private JButton analyzeButton;
    private JButton clearButton;

    public CompilerGUI() {
        super("Mini-Compilateur JavaScript (Lexer + Parser)");

        initComponents();
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(900, 600);
        setLocationRelativeTo(null); // centre la fenêtre
        setVisible(true);
    }

    private void initComponents() {
        // --- Zone de code source (haut) ---
        codeArea = new JTextArea();
        codeArea.setFont(new Font("Consolas", Font.PLAIN, 14));
        codeArea.setText("""
            // Exemple de test
            let age = 15;
            age++;
            if (age < 18) {
                age = age + 1;
            } else {
                age = age - 1;
            }
            """);

        JScrollPane codeScroll = new JScrollPane(codeArea);
        codeScroll.setBorder(BorderFactory.createTitledBorder("Code source"));

        // --- Zone des tokens ---
        tokensArea = new JTextArea();
        tokensArea.setEditable(false);
        tokensArea.setFont(new Font("Consolas", Font.PLAIN, 12));
        JScrollPane tokensScroll = new JScrollPane(tokensArea);
        tokensScroll.setBorder(BorderFactory.createTitledBorder("Tokens"));

        // --- Zone des erreurs ---
        errorsArea = new JTextArea();
        errorsArea.setEditable(false);
        errorsArea.setFont(new Font("Consolas", Font.PLAIN, 12));
        JScrollPane errorsScroll = new JScrollPane(errorsArea);
        errorsScroll.setBorder(BorderFactory.createTitledBorder("Erreurs lex./syn."));

        // --- Panel bas avec tokens + erreurs côte à côte ---
        JSplitPane bottomSplit = new JSplitPane(
                JSplitPane.HORIZONTAL_SPLIT,
                tokensScroll,
                errorsScroll
        );
        bottomSplit.setResizeWeight(0.5); // moitié-moitié

        // --- Boutons ---
        analyzeButton = new JButton("Analyser");
        analyzeButton.addActionListener(this::onAnalyze);

        clearButton = new JButton("Effacer");
        clearButton.addActionListener(e -> {
            tokensArea.setText("");
            errorsArea.setText("");
        });

        JPanel buttonsPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        buttonsPanel.add(clearButton);
        buttonsPanel.add(analyzeButton);

        // --- Layout général ---
        getContentPane().setLayout(new BorderLayout());
        getContentPane().add(codeScroll, BorderLayout.CENTER);
        getContentPane().add(bottomSplit, BorderLayout.SOUTH);
        getContentPane().add(buttonsPanel, BorderLayout.NORTH);

        // Ajuste la hauteur de la partie basse
        bottomSplit.setPreferredSize(new Dimension(800, 250));
    }

    private void onAnalyze(ActionEvent evt) {
        String code = codeArea.getText();

        tokensArea.setText("");
        errorsArea.setText("");

        try {
            // 1) Analyse lexicale
            Lexer lexer = new Lexer(code);
            List<Token> tokens = lexer.tokenize();

            StringBuilder tokBuf = new StringBuilder();
            tokBuf.append("=== LISTE DES TOKENS ===\n");
            for (Token t : tokens) {
                tokBuf.append(t).append("\n");
            }
            tokensArea.setText(tokBuf.toString());

            StringBuilder errBuf = new StringBuilder();

            if (!lexer.getErrors().isEmpty()) {
                errBuf.append("=== ERREURS LEXICALES ===\n");
                for (String e : lexer.getErrors()) {
                    errBuf.append(e).append("\n");
                }
                errBuf.append("\n");
            }

            // 2) Analyse syntaxique seulement si pas d'erreurs lexicales
            Parser parser = new Parser(tokens);
            parser.parseProgram();

            if (!parser.getErrors().isEmpty()) {
                errBuf.append("=== ERREURS SYNTAXIQUES ===\n");
                for (String e : parser.getErrors()) {
                    errBuf.append(e).append("\n");
                }
            } else if (lexer.getErrors().isEmpty()) {
                errBuf.append("✅ Programme syntaxiquement correct.\n");
            }

            errorsArea.setText(errBuf.toString());

        } catch (Exception ex) {
            errorsArea.setText("Exception pendant l'analyse :\n" + ex.getMessage());
            ex.printStackTrace();
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(CompilerGUI::new);
    }
}
